package com.example.addexpense

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.*

//the start 
class MainActivity : AppCompatActivity() {
    //linking to the XML UI components
    private lateinit var etDescription: EditText
    private lateinit var etCategory: EditText
    private lateinit var etDate: EditText
    private lateinit var etStartTime: EditText
    private lateinit var etEndTime: EditText
    private lateinit var btnAddPhoto: Button
    private lateinit var btnSave: Button
    private lateinit var imagePreview: ImageView

    //this is store the image that was selected
    private var imageUri: Uri? = null

    //this activity used to select image from the gallery
    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            imageUri = it
            imagePreview.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //linking the UI components to their various xml ids
        etDescription = findViewById(R.id.etDescription)
        etCategory = findViewById(R.id.etCategory)
        etDate = findViewById(R.id.etDate)
        etStartTime = findViewById(R.id.etStartTime)
        etEndTime = findViewById(R.id.etEndTime)
        btnAddPhoto = findViewById(R.id.btnAddPhoto)
        btnSave = findViewById(R.id.btnSave)
        imagePreview = findViewById(R.id.imagePreview)

        //calling the setup functions
        setupDatePicker()
        setupTimePickers()
        setupImagePicker()
        setupSaveButton()
    }

    //function that opens the date picker
    //setting the selected date
    private fun setupDatePicker() {
        etDate.setOnClickListener {
            val calendar = Calendar.getInstance()

            DatePickerDialog(this,
                { _, year, month, day ->
                    etDate.setText("$day/${month + 1}/$year")
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    //function that handles the start time function
    //function that handles the end time function
    private fun setupTimePickers() {

        //the start time picker
        etStartTime.setOnClickListener {
            TimePickerDialog(this,
                { _, hour, minute ->
                    etStartTime.setText(String.format("%02d:%02d", hour, minute))
                }, 12, 0, true).show()
        }

        //the end time picker
        etEndTime.setOnClickListener {
            TimePickerDialog(this,
                { _, hour, minute ->
                    etEndTime.setText(String.format("%02d:%02d", hour, minute))
                }, 12, 0, true).show()
        }
    }

    //the function that helps launch image picker
    //the third line opens gallery to select image
    private fun setupImagePicker() {
        btnAddPhoto.setOnClickListener {
            imagePicker.launch("image/*")
        }
    }

    //this function is to save all the activity during the process
    private fun setupSaveButton() {
        btnSave.setOnClickListener {

            //getting all the users input from the process
            val description = etDescription.text.toString()
            val category = etCategory.text.toString()
            val date = etDate.text.toString()
            val startTime = etStartTime.text.toString()
            val endTime = etEndTime.text.toString()

            //validation for all the functions
            //everything has to be filled in for your expense to be saved successfully
            //if any field isn't filled in by a user a message will pop up "please fill in"
            if (description.isEmpty()) {
                etDescription.error = "Please fill in"
                return@setOnClickListener
            }

            if (category.isEmpty()) {
                etCategory.error = "Please fill in"
                return@setOnClickListener
            }

            if (date.isEmpty()) {
                etDate.error = "Please fill in"
                return@setOnClickListener
            }

            if (startTime.isEmpty()) {
                etStartTime.error = "Please fill in"
                return@setOnClickListener
            }

            if (endTime.isEmpty()) {
                etEndTime.error = "Please fill in"
                return@setOnClickListener
            }

            //this is to check the image
            if (imageUri == null) {
                Toast.makeText(this, "No image added ", Toast.LENGTH_SHORT).show()
            }
            //if everything was filled in properly
            // the expense will be saved successfully
            //a notification will pop up for the user to confirm that with them
            Toast.makeText(this, "Congrats your expense saved successfully!", Toast.LENGTH_SHORT).show()

            //clearing all the fields
            //setting it back to default for the next expense to be filled in
            etDescription.text.clear()
            etCategory.text.clear()
            etDate.text.clear()
            etStartTime.text.clear()
            etEndTime.text.clear()
            imagePreview.setImageResource(0)
        }
    }
}
//the end